export default {
    regular:'ShipporiMinchoB1-Bold'
}