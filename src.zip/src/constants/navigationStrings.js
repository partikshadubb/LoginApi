export default {
    LOGIN:"login",
    SIGNUP:'signup'
}