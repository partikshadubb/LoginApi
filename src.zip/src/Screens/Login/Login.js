import React ,{ Component } from "react";
import {View,Text } from "react-native";
import reactNativeConfig from "../../../react-native.config";
import navigationStrings from "../../constants/navigationStrings";
import fontFamily from "../../styles/fontFamily";

//import Test from "./Test";

class Login extends Component{
   

  render(){

    return(
      <View style={{flex:1,justifyContent:"center",alignItems:"center",backgroundColor:"pink"}}>
          <Text 
          
            onPress={()=>this.props.navigation.navigate(navigationStrings.SIGNUP)}
          style={{fontFamily:fontFamily.regular}}>Go To Signup....</Text>
          <Text style={{fontFamily:fontFamily.regular}}>hiiii</Text>
      </View>
    )
  }
}


export default Login;